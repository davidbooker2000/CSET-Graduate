<?php //Header
/*
Plugin Name: WP Coda Slider
Plugin URI: http://wp-performance.com/wp-coda-slider/
Description: Coda Slider featured category slider with shortcodes
Author: c3mdigital
Author URI: http://c3mdigital.com/
Version: 0.2.1
License: GPL v2 - http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
*/
?>
<?php
$my_wpcodaslider = new wpcodaslider();
class wpcodaslider{

	var $shortcode_name = 'wpcodaslider';
	var $pattern = '<!-- wpcodaslider -->';
	var $posts_content = '';

	function wpcodaslider() {
		add_shortcode( $this->shortcode_name, array( &$this, 'shortcode' ) );
		add_action( 'the_posts', array( &$this, 'wpcodaslider_scripts' ) );
	}

	// insert the shortcode in any page ie: [wpcodaslider id=slidername cat=4 show=3] will show first three post in category with id of 4
	function shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'cat' => null,
		    'id'  =>  null,
			'show' => null,
			'args' => null
		), $atts ) );

		//Make sure there is a query and name
		if (! $cat || ! $id)
			return 'Could not load slider. Mallformed shortcode.';
	$o = '
		<div class="coda-slider-wrapper">
			<div class="coda-slider preload" id="'. $id .'">';

		$posts = get_posts('post_type=post&order=desc&cat= '. $cat . '&numberposts= ' . $show . '');
		foreach($posts as $post){

			$o.=
			'<div class="panel" id="post-' . $post->ID . '">
				<div class="panel-wrapper">
					<h2 class="title">' . $post->post_title . '</h2>
					' . $post->post_content . '
				</div> <!-- .panel-wrapper -->
			</div><!-- .panel #post-$id -->';
		}


		$o.='
				</div><!-- .coda-slider .preload -->
			</div><!-- coda-slider-wrapper -->
			<script type="text/javascript">
	jQuery(document).ready(function($){
				$().ready(function() {
					$(\'#'. $id .'\').codaSlider({' . $args .'});
				});
	});
			</script>';


		return $o;
	}

	function wpcodaslider_scripts($posts) {


		if (empty($posts)) return $posts;

		$shortcode_found = false; // use this flag to see if styles and scripts need to be enqueued
		foreach ($posts as $post) {
			if (stripos($post->post_content, 'wpcodaslider')) {
				$shortcode_found = true; // bingo!
				break;
			}
		}

		if ($shortcode_found) {
			//enqueue scripts
			wp_enqueue_script('coda_slider', WP_PLUGIN_URL . '/wp-coda-slider/js/coda.slider.js',
			array('jquery'));

			//enqueue style sheet
			wp_enqueue_style('coda_slider', WP_PLUGIN_URL . '/wp-coda-slider/css/coda-slider-2.0.css');
		}

		return $posts;
	}

}
?>
