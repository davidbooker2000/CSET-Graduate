# jQuery - Horizontal Accordion
# Version 2.00.00 Alpha 1
#
# portalZINE(R) - New Media Network
# http://www.portalzine.de
#
# Alexander Graef
# portalzine@gmail.com
#
# Copyright 2007-2009
#

History

Version 0.5
First release

Version 0.51
Updated content handling and position of the click handlers. 
Will be moving this to a plugin and allow a more generic usage.

Version 0.52
Disable click for open content

Version 2.000.00 Alpha
Complete rewrite and works with jQuery 1.3.2
no additional plugins required
 